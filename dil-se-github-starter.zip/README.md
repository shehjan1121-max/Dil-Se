# Dil Se

Public repository for the Dil Se social/dating app and its public legal-information website.

## Repository contents

- `index.html` — GitHub Pages landing page
- `privacy-policy/index.html` — privacy policy draft (must be completed before publishing)
- `terms/index.html` — terms draft (must be completed before publishing)
- `data-deletion/index.html` — account/data deletion instructions (must be completed before publishing)
- `app/README.md` — location for the app source code

## Publish with GitHub Pages

1. Create a **public** repository named `dil-se` under the GitHub account `Shajahan`.
2. Upload all files and folders from this package to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. After GitHub Pages finishes publishing, check the site and each policy URL.

Expected URLs:

- Website: https://shajahan.github.io/dil-se/
- Privacy: https://shajahan.github.io/dil-se/privacy-policy/
- Terms: https://shajahan.github.io/dil-se/terms/
- Data deletion: https://shajahan.github.io/dil-se/data-deletion/

## Important before launch

The policy pages are starter drafts with clearly marked placeholders. Do not submit them to an app store or publish them as final until the actual app data practices, contact details, age requirements, moderation/safety practices, retention, processors, and deletion process have been verified and the drafts completed.

## App source

Put the actual Dil Se app source code in `app/` (or replace that folder with your chosen framework's project structure). No app source code was supplied when this scaffold was created.
